# 🐛 BugBounty Hunter

Automated vulnerability scanner designed for bug bounty programs. Crawls a target, discovers attack surface, and actively tests for common web vulnerabilities.

> ⚠️ **Legal notice** — Only run this tool against targets you have explicit written permission to test. Unauthorised scanning is illegal.

---

## Features

| Module | What it tests |
|---|---|
| **Recon** | Crawls the target, discovers URLs, forms, params, and subdomains |
| **XSS** | Reflected XSS via URL parameters and HTML forms |
| **SQLi** | Error-based and time-based blind SQL injection |
| **LFI** | Local File Inclusion via path traversal payloads |
| **SSRF** | Server-Side Request Forgery (AWS/GCP metadata, localhost) |
| **Open Redirect** | Common redirect parameters pointing to external domains |
| **Headers** | Missing security headers & version disclosure |

## Installation

```bash
git clone https://github.com/youruser/bugbounty-hunter.git
cd bugbounty-hunter
pip install -r requirements.txt
```

## Usage

```bash
# Full scan, HTML report
python main.py --target https://example.com

# Passive recon only (no active fuzzing)
python main.py --target https://example.com --passive

# Run specific modules only
python main.py --target https://example.com --modules xss sqli headers

# With auth cookies, custom headers, and JSON output
python main.py \
  --target https://example.com \
  --cookies "session=abc123; csrf=xyz" \
  --headers "Authorization: Bearer <token>" \
  --format json \
  --threads 20

# Verbose mode
python main.py --target https://example.com --verbose
```

## CLI Options

| Flag | Default | Description |
|---|---|---|
| `--target` / `-t` | *required* | Target URL |
| `--modules` / `-m` | `all` | Modules: `recon xss sqli lfi ssrf open_redirect headers all` |
| `--output` / `-o` | `reports/` | Output directory |
| `--format` / `-f` | `html` | Report format: `html json txt` |
| `--threads` | `10` | Concurrent threads |
| `--timeout` | `10` | Request timeout (seconds) |
| `--cookies` / `-c` | — | Cookie string |
| `--headers` / `-H` | — | Custom headers (repeatable) |
| `--crawl-depth` | `2` | Crawler depth |
| `--passive` | off | Passive mode (recon + headers only) |
| `--verbose` / `-v` | off | Verbose output |

## Report

Reports are saved to `reports/` (configurable). The HTML report includes:

- Severity summary dashboard
- Full findings table with evidence
- Discovered URLs and subdomains

## Exit codes

| Code | Meaning |
|---|---|
| `0` | Scan complete, no critical/high findings |
| `1` | Critical or high severity findings detected |

## Project structure

```
bugbounty-hunter/
├── main.py              # CLI entry point
├── requirements.txt
├── modules/
│   ├── recon.py         # Crawler + subdomain enumeration
│   ├── scanner.py       # XSS, SQLi, LFI, SSRF, redirect, headers
│   ├── reporter.py      # HTML / JSON / TXT report generation
│   └── utils.py         # Shared helpers
└── reports/             # Generated reports (gitignored)
```

## Extending

Add new scan modules by:
1. Adding a method `scan_<name>(self) -> list[dict]` to `VulnScanner`
2. Adding `"<name>"` to the `choices` list in `main.py`
3. Adding it to the `active_modules` dict in `main()`

Use the `finding()` helper from `utils.py` to return standardised dicts.

## Disclaimer

This tool is provided for **educational purposes and authorised security testing only**. The authors accept no liability for misuse.
